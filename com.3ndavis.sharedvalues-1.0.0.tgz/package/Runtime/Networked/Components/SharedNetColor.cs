
   //Copyright 2026 Ethan Davis

   //Licensed under the Apache License, Version 2.0 (the "License");
   //you may not use this file except in compliance with the License.
   //You may obtain a copy of the License at
   //  http://www.apache.org/licenses/LICENSE-2.0

   //Unless required by applicable law or agreed to in writing, software
   //distributed under the License is distributed on an "AS IS" BASIS,
   //WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   //See the License for the specific language governing permissions and
   //limitations under the License.
   
   
   
#if Fishy
using FishNet.Object;
using FishNet.Object.Synchronizing;
#endif
using SharedValues.Core;
using UnityEngine;

namespace SharedValues.Networked
{
    public class SharedNetColor : SharedNetValue<Color, SharedColorReference>
    {
        private readonly SyncVar<Color> networkValue = new SyncVar<Color>(new SyncTypeSettings(WritePermission.ClientUnsynchronized, ReadPermission.ExcludeOwner));

        //require ownership is false since that check is already done in SetValue();
        [ServerRpc(RequireOwnership = false, RunLocally = true)] 
        protected override void SetNetworkValue(Color value)
        {
            //this causes the subscription in OnEnable to trigger
            networkValue.Value = value;
        }
        void OnEnable()
        {
            networkValue.OnChange += SetLocalValue;
        }

        void OnDisable()
        {
            networkValue.OnChange -= SetLocalValue;
        }
    }
}
